import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Lecturer } from '../lecturer';
import { LecturerService } from '../lecturer.service';

@Component({
  selector: 'app-lecturer-list',
  templateUrl: './lecturer-list.component.html',
  styleUrls: ['./lecturer-list.component.css']
})
export class LecturerListComponent implements OnInit {
  
  lecturer:Observable<Lecturer[]>

  constructor(private lecturerService:LecturerService, private router : Router) {}

  public getDataLecturer(){
    this.lecturer = this.lecturerService.getListLecturer();
  }

  public goToDetail(id:String){
    this.router.navigate(['detail-lecturer', id]);
  }
  
  public goToEdit(id:String){
    this.router.navigate(['update-lecturer', id]);
  }

  delete(id:String){
    this.lecturerService.deleteLecturer(id).subscribe(
      (data:true)=> {
        alert('Data Berhasil di Hapus');
        this.getDataLecturer();
      },
      error=>console.error(error)
    );
  }

  ngOnInit() {
    this.getDataLecturer();
  }

}
