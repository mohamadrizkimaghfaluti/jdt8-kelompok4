import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Lecturer } from '../lecturer';
import { LecturerService } from '../lecturer.service';

@Component({
  selector: 'app-lecturer-create',
  templateUrl: './lecturer-create.component.html',
  styleUrls: ['./lecturer-create.component.css']
})
export class LecturerCreateComponent implements OnInit {

  lecturer : Lecturer = new Lecturer();

  constructor(private lecturerService: LecturerService, private router: Router) { }
  
  ngOnInit() {
  }

  save(){
    if(this.lecturer.lecturerIdNumber==null || this.lecturer.lecturerIdNumber==""){
      alert('Lecturer ID Number Tidak Boleh Kosong !');
    }
    else if(this.lecturer.fullName==null || this.lecturer.fullName==""){
      alert('Full Name Tidak Boleh Kosong!');
    }
    else if(this.lecturer.address==null || this.lecturer.address==""){
      alert('Address Tidak Boleh Kosong!');
    }
    else if(this.lecturer.email==null || this.lecturer.email==""){
      alert('Email Tidak Boleh Kosong!');
    }
    else if(this.lecturer.phone==null || this.lecturer.phone==""){
      alert('Phone Tidak Boleh Kosong!');
    }
    else{
      this.lecturerService.createLecturer(this.lecturer).subscribe(
        (response:true)=>{
          this.back();
        },
        (response:false)=>{
          alert('ID Lecturer Sudah Terdaftar')
        }
      );
    }
  }

  submit(){
    this.save();
  }

  back(){
    this.router.navigate(['lecturer']);
  }

}
