export class Student {
    idStudent:String;
    studentIdNumber:String;
    fullName:String;
    address:String;
    email:String;
    phone:String;
    studyProgram:String;
}