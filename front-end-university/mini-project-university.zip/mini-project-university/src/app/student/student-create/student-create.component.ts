import { Component, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-create',
  templateUrl: './student-create.component.html',
  styleUrls: ['./student-create.component.css']
})
export class StudentCreateComponent implements OnInit {

  student : Student = new Student();

  constructor(private studentService: StudentService, private router:Router) { }

  ngOnInit() {

  }

  save(){
    if(this.student.studentIdNumber==null || this.student.studentIdNumber==""){
      alert('Student ID Number Tidak Boleh Kosong!');
    }
    else if(this.student.fullName==null || this.student.fullName=="") {
      alert('Full Name Tidak Boleh Kosong!');
    }
    else if(this.student.address==null || this.student.address=="") {
      alert('Address Tidak Boleh Kosong!');
    }
    else if(this.student.email==null || this.student.email=="") {
      alert('Email Tidak Boleh Kosong!');
    }
    else if(this.student.phone==null || this.student.phone=="") {
      alert('Phone Number Tidak Boleh Kosong!');
    }
    else if(this.student.studyProgram==null || this.student.studyProgram=="") {
      alert('Study Program Tidak Boleh Kosong!');
    }
    else{
      this.studentService.createStudent(this.student).subscribe(
        (response:true)=>{
          this.back();
        },
        (response:false)=>{
          alert('Id Student Sudah Terdaftar');
        }
      );
    }
  }

  submit(){
    this.save();
  }

  back(){
    this.router.navigate(['student']);
  }

  

}
