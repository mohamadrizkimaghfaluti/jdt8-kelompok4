import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from './subject';

@Injectable({
  providedIn: 'root'
})
export class SubjectService {

  private baseUrl = 'http://localhost:8080';

  constructor(private http : HttpClient) { }

  public getListSubject():Observable<any>{
    return this.http.get(`${this.baseUrl}/subject`);
  }

  public createSubject(subject:Subject):Observable<any>{
    return this.http.post(`${this.baseUrl}/subject/create`, subject);
  }

  public getDataSubjectById(id:String):Observable<any>{
    return this.http.get(`${this.baseUrl}/subject/getIdSubject/${id}`);
  }

  public updateSubject(subject:Subject):Observable<any>{
    return this.http.put(`${this.baseUrl}/subject/update`, subject);
  }

  public deleteSubject(id:String):Observable<any>{
    return this.http.delete(`${this.baseUrl}/subject/delete/${id}`)
  }

}
