import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  student:Observable<Student[]>

  constructor(private studentService:StudentService, private router: Router) { }

  public getDataStudent(){
    this.student = this.studentService.getListStudent();
  }

  public goToDetail(id:String){
    this.router.navigate(['detail-student', id]);
  }

  public goToEdit(id:String){
    this.router.navigate(['update-student', id]);
  }

  delete(id:String){
    this.studentService.deleteStudent(id).subscribe(
      (data:true) => {
        alert('Data Berhasil di Hapus');
        this.getDataStudent();
      },
      error=>console.log(error)
    );
  }
    
  ngOnInit() {
    this.getDataStudent();
  }

}
