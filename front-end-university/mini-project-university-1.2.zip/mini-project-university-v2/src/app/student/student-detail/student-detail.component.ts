import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent implements OnInit {

  id:String;
  student: Student;

  constructor(private studentService: StudentService, private route: ActivatedRoute, private router: Router) { }

  public dataStudent(){
    this.student = new Student;
    this.id = this.route.snapshot.params['id'];
    this.studentService.getDataStudentById(this.id).subscribe(
      data=>{
        console.log(data);
        this.student = data;
      },
      error=>console.log(error)
    );
  }

  public back(){
    this.router.navigate(['student']);
  }

  ngOnInit() {
    this.dataStudent();
  }

}
