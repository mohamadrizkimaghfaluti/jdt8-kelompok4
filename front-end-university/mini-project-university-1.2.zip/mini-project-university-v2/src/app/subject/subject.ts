export class Subject {
    codeSubject:String;
    nameSubject:String;
    sks:number;
    semester:number;
}