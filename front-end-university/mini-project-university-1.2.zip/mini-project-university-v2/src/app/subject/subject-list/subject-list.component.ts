import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Subject } from '../subject';
import { SubjectService } from '../subject.service';

@Component({
  selector: 'app-subject-list',
  templateUrl: './subject-list.component.html',
  styleUrls: ['./subject-list.component.css']
})
export class SubjectListComponent implements OnInit {

  subject:Observable<Subject[]>

  constructor(private subjectService:SubjectService, private router : Router) { }

  public getDataSubject(){
    this.subject = this.subjectService.getListSubject();
  }

  public goToEdit(id:String){
    this.router.navigate(['update-subject', id]);
  }
  delete(id:String){
    this.subjectService.deleteSubject(id).subscribe(
      (data:true) => {
        alert('Data Berhasil di Hapus');
        this.getDataSubject();
      },
      error=>console.log(error)
    );
  }

  ngOnInit() {
    this.getDataSubject();
  }

}
