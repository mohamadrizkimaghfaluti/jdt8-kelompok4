import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-update',
  templateUrl: './student-update.component.html',
  styleUrls: ['./student-update.component.css']
})
export class StudentUpdateComponent implements OnInit {

  student: Student;
  id:String;

  constructor(private studentService: StudentService, private router:Router, private route:ActivatedRoute) { }

  public updateDataStudent(){
    this.studentService.updateStudent(this.student).subscribe(
      data=>{
        console.log(data);
        this.backToList();
      },
      error=>console.log(error)
    );
  }

  public data(){
    this.id = this.route.snapshot.params['id'];
    this.student = new Student;
    this.studentService.getDataStudentById(this.id).subscribe(
      data=>{
        this.student = data;
      },
      error=>console.log(error)
    );
  }

  submit(){
    this.updateDataStudent();
  }

  public backToList(){
    this.router.navigate(['student']);
  }

  ngOnInit() {
    this.data();
  }

}
