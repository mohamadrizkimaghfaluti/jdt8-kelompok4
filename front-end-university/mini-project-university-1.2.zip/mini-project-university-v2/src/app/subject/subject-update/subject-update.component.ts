import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from '../subject';
import { SubjectService } from '../subject.service';

@Component({
  selector: 'app-subject-update',
  templateUrl: './subject-update.component.html',
  styleUrls: ['./subject-update.component.css']
})
export class SubjectUpdateComponent implements OnInit {

  subject: Subject;
  id:String;

  constructor(private subjectService: SubjectService, private router:Router, private route:ActivatedRoute) { }

  public UpdateDataSubject(){
    this.subjectService.updateSubject(this.subject).subscribe(
      data=>{
        console.log(data);
        this.backToList();
      },
      error=>console.log(error)
    );
  }

  public data(){
    this.id=this.route.snapshot.params['id'];
    this.subject = new Subject;
    this.subjectService.getDataSubjectById(this.id).subscribe(  
      data=>{
        this.subject = data;
      },
      error=> console.log(error)
    );
  }

  submit(){
    this.UpdateDataSubject();
  }

  public backToList(){
    this.router.navigate(['subject']);
  }

  ngOnInit() {
    this.data();
  }
}

