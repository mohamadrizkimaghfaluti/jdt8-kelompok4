import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentCreateComponent } from './student/student-create/student-create.component';
import { StudentUpdateComponent } from './student/student-update/student-update.component';
import { StudentListComponent } from './student/student-list/student-list.component';
import { StudentDetailComponent } from './student/student-detail/student-detail.component';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { SubjectCreateComponent } from './subject/subject-create/subject-create.component';
import { SubjectDetailComponent } from './subject/subject-detail/subject-detail.component';
import { SubjectListComponent } from './subject/subject-list/subject-list.component';
import { SubjectUpdateComponent } from './subject/subject-update/subject-update.component';
import { LecturerUpdateComponent } from './lecturer/lecturer-update/lecturer-update.component';
import { LecturerListComponent } from './lecturer/lecturer-list/lecturer-list.component';
import { LecturerCreateComponent } from './lecturer/lecturer-create/lecturer-create.component';
import { LecturerDetailComponent } from './lecturer/lecturer-detail/lecturer-detail.component';
import { HomePageComponent } from './home-page/home-page.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentCreateComponent,
    StudentUpdateComponent,
    StudentListComponent,
    StudentDetailComponent,
    SubjectCreateComponent,
    SubjectDetailComponent,
    SubjectListComponent,
    SubjectUpdateComponent,
    LecturerUpdateComponent,
    LecturerListComponent,
    LecturerCreateComponent,
    LecturerDetailComponent,
    HomePageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
