import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Lecturer } from './lecturer';

@Injectable({
  providedIn: 'root'
})
export class LecturerService {

  private baseUrl = 'http://localhost:8080';

  constructor(private http:HttpClient) { }

  public getListLecturer():Observable<any>{
    return this.http.get(`${this.baseUrl}/lecturer`);
  }

  public createLecturer(lecturer:Lecturer):Observable<any>{
    return this.http.post(`${this.baseUrl}/lecturer/create`, lecturer);
  }

  public getDataLecturerById(id:String):Observable<any>{
    return this.http.get(`${this.baseUrl}/lecturer/getById/${id}`);
  }
  
  public updateLecturer(lecturer:Lecturer):Observable<any>{
    return this.http.put(`${this.baseUrl}/lecturer/update`, lecturer);
  }

  public deleteLecturer(id:String):Observable<any>{
    return this.http.delete(`${this.baseUrl}/lecturer/delete/${id}`);
  }
}
