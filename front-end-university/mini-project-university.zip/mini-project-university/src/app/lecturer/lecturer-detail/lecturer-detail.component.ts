import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Lecturer } from '../lecturer';
import { LecturerService } from '../lecturer.service';

@Component({
  selector: 'app-lecturer-detail',
  templateUrl: './lecturer-detail.component.html',
  styleUrls: ['./lecturer-detail.component.css']
})
export class LecturerDetailComponent implements OnInit {

  id:String;
  lecturer: Lecturer;

  constructor(private lecturerService: LecturerService, private route : ActivatedRoute, private router :Router) { }

  public dataLecturer(){
    this.lecturer = new Lecturer;
    this.id = this.route.snapshot.params['id'];
    this.lecturerService.getDataLecturerById(this.id).subscribe(
      data=>{
        console.log(data);
        this.lecturer = data;
      },
      error=>console.log(error)
    );
  }

  public back(){
    this.router.navigate(['lecturer']);
  }

  ngOnInit() {
    this.dataLecturer();
  }

}
