export class Lecturer {
    idLecturer:String;
    lecturerIdNumber:String;
    fullName:String;
    address:String;
    email:String;
    phone:String;
}