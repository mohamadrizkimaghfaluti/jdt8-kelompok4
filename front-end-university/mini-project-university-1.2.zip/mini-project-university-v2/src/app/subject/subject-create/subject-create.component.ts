import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from '../subject';
import { SubjectService } from '../subject.service';

@Component({
  selector: 'app-subject-create',
  templateUrl: './subject-create.component.html',
  styleUrls: ['./subject-create.component.css']
})
export class SubjectCreateComponent implements OnInit {

  subject : Subject = new Subject();

  constructor(private subjectService : SubjectService, private router : Router) { }

  ngOnInit() {
  }
  
  save(){
    if(this.subject.nameSubject==null || this.subject.nameSubject=="") {
      alert('Nama Subject Tidak Boleh Kosong !');
    }
    else if(this.subject.sks==null || this.subject.sks==0) {
      alert('SKS Tidak Boleh Kosong !');
    }
    else if(this.subject.semester==null || this.subject.semester==0) {
      alert('Semester Tidak Boleh Kosong !');
    }
    else {
      this.subjectService.createSubject(this.subject).subscribe(
        (response)=>{
          this.back();
        },
        (error)=> console.log(error)
      );
    }
  }

  submit(){
    this.save();
  }

  back(){
    this.router.navigate(['subject']);
  }

}
