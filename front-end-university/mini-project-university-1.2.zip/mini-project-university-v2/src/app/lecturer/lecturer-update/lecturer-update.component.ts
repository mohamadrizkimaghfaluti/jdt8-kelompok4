import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Lecturer } from '../lecturer';
import { LecturerService } from '../lecturer.service';

@Component({
  selector: 'app-lecturer-update',
  templateUrl: './lecturer-update.component.html',
  styleUrls: ['./lecturer-update.component.css']
})
export class LecturerUpdateComponent implements OnInit {

  lecturer: Lecturer;
  id:String;

  constructor(private lecturerService: LecturerService, private router:Router, private route:ActivatedRoute) { }

  public updateDataLecturer(){
    this.lecturerService.updateLecturer(this.lecturer).subscribe(
      data=>{
        console.log(data);
        this.backToList();
      },
      error=>console.log(error)
    );
  }

  public data(){
    this.id = this.route.snapshot.params['id'];
    this.lecturer = new Lecturer;
    this.lecturerService.getDataLecturerById(this.id).subscribe(
      data=>{
        this.lecturer = data;
      },
      error=>console.log(error)
    );
  }

  submit(){
    this.updateDataLecturer();
  }

  public backToList(){
    this.router.navigate(['lecturer']);
  }

  ngOnInit() {
    this.data();
  }

}
