import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { LecturerCreateComponent } from './lecturer/lecturer-create/lecturer-create.component';
import { LecturerDetailComponent } from './lecturer/lecturer-detail/lecturer-detail.component';
import { LecturerListComponent } from './lecturer/lecturer-list/lecturer-list.component';
import { LecturerUpdateComponent } from './lecturer/lecturer-update/lecturer-update.component';
import { StudentCreateComponent } from './student/student-create/student-create.component';
import { StudentDetailComponent } from './student/student-detail/student-detail.component';
import { StudentListComponent } from './student/student-list/student-list.component';
import { StudentUpdateComponent } from './student/student-update/student-update.component';
import { SubjectCreateComponent } from './subject/subject-create/subject-create.component';
import { SubjectListComponent } from './subject/subject-list/subject-list.component';
import { SubjectUpdateComponent } from './subject/subject-update/subject-update.component';

const routes: Routes = [
  {path:'', redirectTo:'home-page',pathMatch:'full'},
  {path:'home-page', component:HomePageComponent},
  {path:'student', component:StudentListComponent},
  {path:'add-student', component:StudentCreateComponent},
  {path:'update-student/:id', component:StudentUpdateComponent},
  {path:'detail-student/:id', component:StudentDetailComponent},
  {path:'subject', component:SubjectListComponent},
  {path:'add-subject', component:SubjectCreateComponent},
  {path:'update-subject/:id', component:SubjectUpdateComponent},
  {path:'lecturer', component:LecturerListComponent},
  {path:'add-lecturer', component:LecturerCreateComponent},
  {path:'update-lecturer/:id', component:LecturerUpdateComponent},
  {path:'detail-lecturer/:id', component:LecturerDetailComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
