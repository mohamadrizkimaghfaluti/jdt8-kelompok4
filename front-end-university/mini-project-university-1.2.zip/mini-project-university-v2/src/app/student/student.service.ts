import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from './student';


@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private baseUrl = 'http://localhost:8080';

  constructor(private http:HttpClient) { }

  public getListStudent():Observable<any>{
    return this.http.get(`${this.baseUrl}/student/getData`);
  }

  public createStudent(student:Student):Observable<any>{
    return this.http.post(`${this.baseUrl}/student/create`, student);
  }
  
  public getDataStudentById(id:String):Observable<any>{
    return this.http.get(`${this.baseUrl}/student/getById/${id}`);
  }

  public updateStudent(student:Student):Observable<any>{
    return this.http.put(`${this.baseUrl}/student/update`, student);
  }

  public deleteStudent(id:String):Observable<any>{
    return this.http.delete(`${this.baseUrl}/student/delete/${id}`);
  }

}
